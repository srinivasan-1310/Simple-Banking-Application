package com.RSk.banking;
import java.util.*;
public class Bank {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("\t\tWelcome");
		System.out.println("\t*****RSA BANK*****");
		System.out.println("Enter your Account Number");
		int accNum=sc.nextInt();
		float Avl_Balance=0;
		
		String fac;
		switch(accNum) {
		case 83700011:
			System.out.println("Account Holder Name : Srinivasan R");
			System.out.println("IFSC Code : RSA00013");
			System.out.println("Branch : Tambaram");
			System.out.println("Branch Phone No : 34567");
			Avl_Balance=20000;
			System.out.print("Available Balance : "+Avl_Balance);
			System.out.println("\n\n____Use The Facility____\n1.Check_Balance\n2.Withdraw_amount\n3.deposite_Cash\n4.Exit");
			for(int i=0;i<=100;i++) {
			fac=sc.next();
			 switch(fac) {
			 case "Withdraw_amount":
				 System.out.println("Enter The Withdraw Amount");
				 int cash=sc.nextInt();
				 if(Avl_Balance>=cash) {
					 System.out.println("$$$ Your Withdraw Successfull $$$");
					 Avl_Balance=Avl_Balance-cash;
				 }
				 else {
					 System.out.println("Oops!\ninsufficient balance pls check your balance");
				 }
				 break;
			 case "Check_Balance":
				 System.out.print("Your Current Available Balance : "+Avl_Balance);
				 break;
			 case "deposite_Cash":
				 System.out.println("Enter The Deposite Amount");
				 int deposite=sc.nextInt();
				 Avl_Balance=deposite+Avl_Balance;
				 System.out.println("****Your Deposite is Succesfull****\nYour Current Balance is : "+Avl_Balance);
				 break;
			 
			 case "Exit":
				 System.out.println("\n__________Thank you__________");
				 System.exit(0);
			 } 
			 }
			
			break;
		case 83700012:
			System.out.println("Account Holder Name : Aadhitya S");
			System.out.println("IFSC Code : RSA00002");
			System.out.println("Branch : Pallavaram");
			System.out.println("Branch Pho : 9876");
			Avl_Balance=50000;
			System.out.print("Ava Balance : "+Avl_Balance);
			System.out.println("\n\n____Use The Facility____\n1.Check_Balance\n2.Check_Withdraw\n3.deposite_Cash\n4.Exit");
			for(int i=0;i<=100;i++) {
			fac=sc.next();
			switch(fac) {
			 case "Withdraw_amount":
				 System.out.println("Enter the withdraw Amount");
				 int cash=sc.nextInt();
				 if(Avl_Balance>=cash) {
					 System.out.println("$$$ Your Withdraw Successfull $$$");
					 Avl_Balance=Avl_Balance-cash;
				 }
				 else {
					 System.out.println("oops!\ninsufficient balance pls check your balance");
				 }
				 break;
			 case "Check_Balance":
				 System.out.print("Your Current Available Balance : "+Avl_Balance);
				 break;
			 case "deposite_Cash":
				 System.out.println("Enter the Deposite Amount");
				 int deposite=sc.nextInt();
				 Avl_Balance=deposite+Avl_Balance;
				 System.out.println("****Your Deposite is Succesfull****\nYour current Balance is : "+Avl_Balance);
				 break;
			 
			 case "Exit":
				 System.out.println("\n__________Thank you__________");
				 System.exit(0);
				 
			 } 
			 }
			
			
			break;
		case 83700013:
			System.out.println("Account Holder Name : Dinesh B");
			System.out.println("IFSC Code : RSA00014");
			System.out.println("Branch : Arcot");
			System.out.println("Branch Phone No : 2486");
			Avl_Balance=150000;
			System.out.print("Ava Balance : "+Avl_Balance);
			System.out.println("\n\n____Use The Facility____\n1.Check_Balance\n2.Withdraw_amount\n3.deposite_Cash\n4.Exit");
			for(int i=0;i<=100;i++) {
			fac=sc.next();
			 switch(fac) {
			 case "Withdraw_amount":
				 System.out.println("Enter The Withdraw Amount");
				 int cash=sc.nextInt();
				 if(Avl_Balance>=cash) {
					 System.out.println("$$$ Your Withdraw Successfull $$$");
					 Avl_Balance=Avl_Balance-cash;
				 }
				 else {
					 System.out.println("oops!\ninsufficient balance please check your balance");
				 }
				 break;
			 case "Check_Balance":
				 System.out.print("Your Current Available Balance : "+Avl_Balance);
				 break;
			 case "deposite_Cash":
				 System.out.println("Enter The Deposite Amount");
				 int deposite=sc.nextInt();
				 Avl_Balance=deposite+Avl_Balance;
				 System.out.println("****Your Deposite is Succesfull****\nYour Current Balance is : "+Avl_Balance);
				 break;
			 
			 case "Exit":
				 System.out.println("\n__________Thank you__________");
				 System.exit(0);
			 } 
			 }
			break;
			default:
				System.out.println("Oops!\nPls Correct The Account Number");
			
			
			
		}
		

	}

}
